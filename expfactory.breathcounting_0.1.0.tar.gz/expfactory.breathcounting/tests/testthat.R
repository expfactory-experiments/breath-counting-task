library(testthat)
library(expfactory.breathcounting)

test_check("expfactory.breathcounting")
